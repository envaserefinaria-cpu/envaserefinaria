# Painel industrial Coamo

Envase e Refinaria usam o mesmo projeto Supabase. O perfil aprovado em `panel_profiles` controla os setores disponíveis. Os lançamentos são lidos de `panel_records` quando o usuário abre um setor.

## Configuração

1. Aplique em ordem as migrações pendentes em `supabase/migrations`.
2. Em Authentication, cadastre ou convide os usuários com e-mail corporativo. Depois da confirmação do e-mail, associe cada usuário a um perfil aprovado em `panel_profiles`. Um operador precisa de um setor. O papel `management` dá acesso aos dois setores.
3. Copie `.env.example` para `.env.local` e preencha a URL do projeto e a chave publicável, ou defina as duas variáveis no ambiente da compilação.
4. Execute `node build.cjs` com Node.js e use `dist/index.html` como entrada da hospedagem estática. Configure as URLs de redirecionamento do Supabase Auth para o endereço publicado antes de usar a confirmação de novos cadastros em produção.

### Convites e avisos

- Publique a Edge Function `staff-invite` após as migrações de avisos e metas. Configure o segredo `PANEL_INVITE_REDIRECT_URL` com o endereço HTTPS do painel e inclua esse endereço com `?recuperar=1` nas URLs permitidas pelo Supabase Auth. Se outros endereços também hospedarem o painel, inclua suas origens em `PANEL_ALLOWED_ORIGINS`, separadas por vírgula.
- O convite é enviado pelo Supabase Auth. O colaborador define a senha ao abrir o link e recebe perfil de operador aprovado pela Gestão no setor cadastrado. A função valida a autorização do gestor no servidor e usa a chave de serviço fornecida pelo ambiente da Edge Function.
- Ao sincronizar produção ou ordens, o Supabase compara o realizado em dias completos com a ordem mensal positiva. A primeira vez que uma meta é atingida, as contas aprovadas recebem um aviso. Na Refinaria, o cálculo é por etapa. Mensagens individuais são gravadas exclusivamente para a conta selecionada.

### Banco de horas, férias e hierarquia

- Em **Escala e agenda → Hierarquia**, a Coordenação atribui Supervisão ou Assistência a contas de operador ativas e vinculadas ao cadastro do setor. Os gestores aprovados existentes têm acesso de Coordenação. Supervisores e assistentes mantêm o acesso ao próprio setor, com as funções adicionais da hierarquia.
- O assistente do turno ou a Coordenação decide a solicitação de BH. A aprovação grava o dia na escala e a decisão vai ao colaborador. Em **Programação de férias**, cadastre o período aquisitivo e confira a data limite antes de programar as férias.
- A migração de alertas instala o trabalho `coamo-alertas-ferias` do Supabase Cron. Ele roda diariamente às 03h15 UTC e gera avisos de planejamento a seis meses e urgentes a dois meses da data limite de períodos ainda sem programação.
- A caixa exibe avisos lidos por 24 horas. A confirmação fica registrada no histórico para o remetente ou a Coordenação.

## Importação e cópias

- Use a tela **Importar dados** do setor correspondente. A importação de produção exige o identificador do movimento. A importação de falhas usa o identificador do relato. As ordens usam a data e, na Refinaria, também a etapa.
- Reimportações idênticas não alteram os registros nem criam novo item no histórico. Alterações no mesmo identificador atualizam o registro. O banco aplica a sincronização do lote em uma transação.
- O gestor pode carregar a cópia local do navegador pela tela de importação e escolher **Restaurar** para acrescentar ou atualizar esses registros no Supabase. A cópia local não é enviada automaticamente. O histórico antigo não é reenviado.
- A configuração de relatórios continua vinculada ao navegador. O cadastro e a concessão de perfis são administrados no Supabase.

## Publicação

Inclua código, migrações e dados fictícios de teste. O projeto e a chave pública são fornecidos na compilação. Mantenha as planilhas industriais, as cópias operacionais, os arquivos `.env.local` e as chaves de serviço fora do repositório.

Execute `node testes/sincronizacao.cjs` para conferir inclusão, deduplicação e atualização com registros fictícios.

Publique todos os arquivos de `dist/`. O HTML carrega a abertura separadamente e tenta WebM antes do MP4.

Em retrato, o painel carrega `abertura-iphone.mp4`, uma versão vertical de 8 segundos. Em telas mais largas, usa os arquivos de abertura originais.

## Gestão do setor

O menu **Gestão** reúne conversa privada, avisos internos, reuniões, histórico e hierarquia. As abas **Gestão de escalas** e **Colaboradores** também ficam neste menu, para contas com permissão de edição. A Coordenação acessa os dois setores. Supervisores e assistentes acessam o próprio setor. A Operação consulta **Escala e agenda** e pode pedir BH ou solicitar suas próprias férias.

Avisos manuais recebem uma duração de 1 a 720 horas a partir do envio. O histórico de envios à Operação conserva registros de leitura. As migrações devem ser aplicadas por ordem de nome, incluindo `20261127000500_responsaveis_por_turno.sql`. Sob **Hierarquia**, salve os responsáveis de cada turno. Uma conta recém-vinculada precisa ter acesso aprovado e o vínculo deve ser salvo novamente para ativar a função.
