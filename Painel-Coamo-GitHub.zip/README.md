# Painel industrial Coamo

Envase e Refinaria usam o mesmo projeto Supabase. O perfil aprovado em `panel_profiles` controla os setores disponíveis. Os lançamentos são lidos de `panel_records` quando o usuário abre um setor.

## Configuração

1. Em um projeto novo, aplique as migrações de `supabase/migrations` em ordem. O projeto atual já recebeu as duas migrações pelo SQL Editor.
2. Em Authentication, cadastre ou convide os usuários com e-mail corporativo. Depois da confirmação do e-mail, associe cada usuário a um perfil aprovado em `panel_profiles`. Um operador precisa de um setor. O papel `management` dá acesso aos dois setores.
3. Copie `.env.example` para `.env.local` e preencha a URL do projeto e a chave publicável, ou defina as duas variáveis no ambiente da compilação.
4. Execute `node build.cjs` com Node.js e use `dist/index.html` como entrada da hospedagem estática. Configure as URLs de redirecionamento do Supabase Auth para o endereço publicado antes de usar a confirmação de novos cadastros em produção.

## Importação e cópias

- Use a tela **Importar dados** do setor correspondente. A importação de produção exige o identificador do movimento. A importação de falhas usa o identificador do relato. As ordens usam a data e, na Refinaria, também a etapa.
- Reimportações idênticas não alteram os registros nem criam novo item no histórico. Alterações no mesmo identificador atualizam o registro. O banco aplica a sincronização do lote em uma transação.
- O gestor pode carregar a cópia local do navegador pela tela de importação e escolher **Restaurar** para acrescentar ou atualizar esses registros no Supabase. A cópia local não é enviada automaticamente. O histórico antigo não é reenviado.
- A configuração de relatórios continua vinculada ao navegador. O cadastro e a concessão de perfis são administrados no Supabase.

## Publicação

Inclua código, migrações e dados fictícios de teste. O projeto e a chave pública são fornecidos na compilação. Mantenha as planilhas industriais, as cópias operacionais, os arquivos `.env.local` e as chaves de serviço fora do repositório.

Execute `node testes/sincronizacao.cjs` para conferir inclusão, deduplicação e atualização com registros fictícios.

Publique todos os arquivos de `dist/`. O HTML carrega a abertura separadamente e tenta WebM antes do MP4.
