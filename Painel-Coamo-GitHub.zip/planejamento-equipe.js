const teamTabs=new Set(['room','bank','vacation','hierarchy','communications']);
const teamPanel=$('team-panel'),teamCommands=$('team-communications');
let teamMember=null, teamView='', teamRequest=0;
const canTeamCommunicate=()=>isManager()||['supervisor','assistant'].includes(teamMember?.role);
const canTeamPlan=()=>isManager()||teamMember?.role==='assistant';
const todayTeam=()=>new Intl.DateTimeFormat('sv-SE',{timeZone:'America/Sao_Paulo'}).format(new Date());
const teamStamp=value=>noticeTimestamp.format(new Date(value));
const teamEscape=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[c]);
const teamOption=(value,text,selected)=>'<option value="'+teamEscape(value)+'" '+(selected?'selected':'')+'>'+teamEscape(text)+'</option>';
const teamTag=(value,tone)=>'<span class="team-tag '+tone+'">'+teamEscape(value)+'</span>';
const teamDate=value=>teamEscape(value?formatDate(value):'—');
function teamVisible(key){
 if(context.leadership){
  if(key==='bank'||key==='vacation')return canTeamPlan();
  return canTeamCommunicate();
 }
 return (key==='bank'||key==='vacation')&&teamMember?.role==='operator';
}
function redrawTeamPanel(){
 $('bank-tab').textContent=context.leadership?'Banco de horas':'Solicitar BH';
 $('vacation-tab').textContent=context.leadership?'Programação de férias':'Solicitar férias';
 const active=teamTabs.has(screen)&&teamVisible(screen);
 teamPanel.hidden=!active;
 for(const key of teamTabs){
  const button=$(key+'-tab');
  button.hidden=!teamVisible(key);
  if(active&&screen===key)button.setAttribute('aria-current','page');
  else button.removeAttribute('aria-current');
 }
 if(!active){
  teamCommands.hidden=true;
  teamView='';
  return;
 }
 if(teamView!==screen){teamView=screen;void loadTeamPanel()}
}
async function loadTeamPanel(){
 const page=screen,request=++teamRequest;
 const valid=()=>request===teamRequest&&screen===page;
 teamCommands.hidden=page!=='communications';
 if(page==='communications'){
  teamPanel.innerHTML='<h2>Avisos e encaminhamentos</h2><p class="muted team-intro">'+
   'Envie ou encaminhe avisos aos colaboradores do seu setor.</p>';
  teamPanel.append(teamCommands);
  if(operationHistory.open)void loadOperationHistory();
  return;
 }
 teamPanel.replaceChildren(node('p','Carregando…','muted'));
 try{
  if(page==='room'){
   showLeadershipRoom();
  }else if(page==='bank'){
   const list=await query(client.rpc('panel_bank_list',{target_sector:currentSector()}));
   if(valid())showBankPanel(list||[]);
  }else if(page==='vacation'){
   const promises=[query(client.rpc('panel_vacation_list',{target_sector:currentSector()}))];
   if(canTeamPlan())promises.push(query(client.rpc('panel_vacation_people_with_admission',{target_sector:currentSector()})));
   const [periods,workers]=await Promise.all(promises);
   if(valid())showVacationPanel(periods||[],workers||[]);
  }else if(page==='hierarchy'){
   const areas=isManager()?Object.keys(sectors):[currentSector()];
   const lists=await Promise.all(areas.map(target_sector=>query(client.rpc('panel_roster',{target_sector}))));
   if(valid())showTeamDirectory(areas,lists);
  }
 }catch{
  if(valid()){
   const retry=node('button','Tentar novamente');
   retry.type='button';retry.onclick=()=>void loadTeamPanel();
   teamPanel.replaceChildren(node('p','Não foi possível carregar. Confira sua conexão.','muted'),retry);
  }
 }
}
async function teamSubmit(form,button,rpc,args,message,refreshScale=false){
 if(form.dataset.saving)return;
 form.dataset.saving='true';
 const buttons=[...form.querySelectorAll('button')];
 buttons.forEach(element=>{element.disabled=true});
 try{
  await query(client.rpc(rpc,args));
  if(refreshScale)await refresh();
  status(message);
  await loadTeamPanel();
 }catch(error){
  const expected=['22023','23505','42501'].includes(error?.code);
  status(expected&&error.code!=='23505'?error.message:error?.code==='23505'?
    'Já existe um registro para essa pessoa, data ou função. Confira antes de tentar novamente.':'Não foi possível concluir. Atualize a tela e tente novamente.');
  button.focus();
 }finally{
  delete form.dataset.saving;
  buttons.forEach(element=>{element.disabled=false});
 }
}

function showLeadershipRoom(){
 teamPanel.innerHTML='<h2>Conversa da Gestão</h2><p class="muted team-intro">'+
  'Área privada da Coordenação, Supervisão e Assistência de '+teamEscape(sectors[currentSector()])+'.</p>'+
  '<form id="leadership-post" class="team-form"><label>Publicar<select name="kind">'+
  '<option value="conversation">Mensagem</option><option value="notice">Aviso interno</option><option value="meeting">Reunião</option></select></label>'+
  '<label hidden>Assunto<input name="subject" maxlength="100"></label>'+
  '<label hidden>Data e hora de Brasília<input name="meeting" type="datetime-local"></label>'+
  '<label hidden>Duração do aviso (em horas)<input name="duration" type="number" min="1" max="720" step="1"></label>'+
  '<label class="wide">Mensagem ou pauta<textarea name="body" maxlength="2000" required></textarea></label>'+
  '<button class="primary" type="submit">Publicar</button></form>'+
  '<div class="leadership-heading"><h3>Publicações da Gestão</h3><button type="button" id="leadership-refresh">Atualizar</button></div>'+
  '<p id="leadership-status" class="muted" role="status"></p><div id="leadership-posts" class="team-stack"></div>'+
  '<button type="button" id="leadership-more" hidden>Ver publicações anteriores</button>';
 const form=$('leadership-post'), fields=form.elements, list=$('leadership-posts'), more=$('leadership-more');
 const feedStatus=$('leadership-status');
 const dateTime=new Intl.DateTimeFormat('pt-BR',{dateStyle:'short',timeStyle:'short',timeZone:'America/Sao_Paulo'});
 let cursor=null, request=0, timer;
 function syncFields(){
  const kind=fields.kind.value;
  for(const [field,visible] of [[fields.subject,kind!=='conversation'],[fields.meeting,kind==='meeting'],[fields.duration,kind==='notice']]){
   field.closest('label').hidden=!visible;
   field.required=visible;
  }
 }
 async function load(append=false){
  const revision=++request;
  clearTimeout(timer);
  feedStatus.textContent='Carregando publicações…';
  more.disabled=true;
  try{
   const rows=await query(client.rpc('panel_leadership_list',{
    target_sector:currentSector(),before_created_at:append?cursor?.created_at:null,before_id:append?cursor?.id:null
   }));
   if(revision!==request||!list.isConnected)return;
   if(!append)list.replaceChildren();
   const page=(rows||[]).slice(0,30);
   for(const post of page){
    const item=node('article','','team-card leadership-post');
    item.append(node('span',{conversation:'Mensagem',notice:'Aviso interno',meeting:'Reunião'}[post.kind],'team-tag'),
     node('small',post.author+' · '+dateTime.format(new Date(post.created_at)),'muted'));
    if(post.subject)item.append(node('h4',post.subject));
    if(post.meeting_at)item.append(node('p','Reunião em '+dateTime.format(new Date(post.meeting_at))+' (Brasília)','muted'));
    if(post.expires_at){
     item.dataset.expiry=Date.parse(post.expires_at);
     item.append(node('p','Expira em '+dateTime.format(new Date(post.expires_at))+' (Brasília)','muted'));
    }
    item.append(node('p',post.body,'leadership-body'));list.append(item);
   }
   cursor=page.at(-1);
   more.hidden=(rows||[]).length<=30;
   const nextExpiry=Math.min(...Array.from(list.querySelectorAll('[data-expiry]'),item=>Number(item.dataset.expiry)));
   if(Number.isFinite(nextExpiry))timer=setTimeout(()=>{if(list.isConnected)void load()},Math.min(2147000000,Math.max(250,nextExpiry-Date.now()+250)));
   feedStatus.textContent=list.childElementCount?'':'Nenhuma publicação neste setor.';
  }catch{
   if(revision===request&&list.isConnected)feedStatus.textContent='Não foi possível carregar as publicações.';
  }finally{if(revision===request)more.disabled=false}
 }
 fields.kind.onchange=syncFields;
 $('leadership-refresh').onclick=()=>void load();
 more.onclick=()=>void load(true);
 form.onsubmit=event=>{
  event.preventDefault();
  const kind=fields.kind.value;
  void teamSubmit(form,event.submitter,'panel_leadership_send',{
   target_sector:currentSector(),post_kind:kind,post_subject:kind==='conversation'?null:fields.subject.value.trim(),
   post_body:fields.body.value.trim(),meeting_time:kind==='meeting'?fields.meeting.value+':00-03:00':null,
   duration_hours:kind==='notice'?Number(fields.duration.value):null
  },'Publicado na Gestão.');
 };
 syncFields();
 void load();
}

function showBankPanel(list){
 const operator=teamMember?.role==='operator'&&!isManager();
 const labels={pending:'Aguardando aprovação',approved:'Aprovada',rejected:'Reprovada'};
 teamPanel.innerHTML='<h2>'+(operator?'Solicitar banco de horas':'Banco de horas')+'</h2><p class="muted team-intro">'+(operator?
   'Solicite um dia. O assistente do seu turno e a Coordenação recebem o pedido.':
   'A aprovação publica o BH na escala e envia a decisão ao colaborador.')+'</p>'+
  (operator?teamMember.registration?'<form id="bank-request-form" class="team-form"><label>Dia solicitado<input type="date" name="date" min="'+todayTeam()+'" required></label><label>Observação (opcional)<input name="note" maxlength="300"></label><div class="wide"><button class="primary">Enviar solicitação</button></div></form>':
   '<p class="muted">Peça à Gestão para vincular sua conta ao cadastro da escala.</p>':'')+
  '<div class="team-stack">'+(list.map(r=>{
   const review=!operator&&r.status==='pending';
   return '<details class="team-card"><summary><span class="team-summary">'+teamEscape(r.employee_name)+' · Turno '+teamEscape(r.shift)+
    ' · '+teamDate(r.requested_date)+' '+teamTag(labels[r.status],r.status)+'</span></summary>'+
    (r.note?'<p>'+teamEscape(r.note)+'</p>':'')+
    (r.approved_date?'<p>BH publicado em <strong>'+teamDate(r.approved_date)+'</strong>.</p>':'')+
    (r.reason?'<p>'+teamEscape(r.reason)+'</p>':'')+
    (r.decided_at?'<p class="muted">Decidida em '+teamEscape(teamStamp(r.decided_at))+'.</p>':'')+
    (review?'<form class="team-form" data-bank-decision="'+r.id+'"><label>Dia para aprovação<input type="date" name="chosen" value="'+r.requested_date+'"></label><label>Observação ou motivo da reprovação<input name="reason" maxlength="300"></label><div class="actions wide"><button class="primary" value="approved">Aprovar e publicar</button><button value="rejected">Reprovar</button></div></form>':'')+'</details>';
  }).join('')||'<p class="muted">Nenhuma solicitação para este perfil.</p>')+'</div>';
 const form=$('bank-request-form');
 if(form)form.onsubmit=event=>{
  event.preventDefault();
  void teamSubmit(form,event.submitter,'panel_bank_request',{target_sector:currentSector(),
    request_day:form.elements.date.value,message:form.elements.note.value},'Solicitação enviada.');
 };
 teamPanel.querySelectorAll('[data-bank-decision]').forEach(form=>{form.onsubmit=event=>{
  event.preventDefault();
  const button=event.submitter,decision=button.value;
  if(decision==='rejected'&&!form.elements.reason.value.trim()){status('Informe o motivo da reprovação.');return}
  if(decision==='approved'&&(!form.elements.chosen.value||form.elements.chosen.value<todayTeam())){
   status('Informe uma data atual ou futura para a aprovação.');return;
  }
  void teamSubmit(form,button,'panel_bank_decide',{request_id:form.dataset.bankDecision,decision,
    chosen_date:form.elements.chosen.value||null,comments:form.elements.reason.value},
    decision==='approved'?'BH publicado na escala.':'Solicitação reprovada. O colaborador recebeu a decisão.',true);
 }});
}
function vacationForm(period,workers){
 const label=period?'<input type="hidden" name="worker" value="'+teamEscape(period.registration)+'">':
  '<label>Colaborador<select name="worker" required><option value="">Selecione</option>'+workers.map(person=>
   teamOption(person.registration,person.full_name+' · Turno '+person.shift)).join('')+'</select></label>';
 return '<form class="team-form" data-vacation-period="'+(period?.id||'')+'">'+label+
  '<label>Data de admissão<input name="admission" type="date" value="'+(period?.admission_date||'')+'" required></label>'+
  '<label>Início do período aquisitivo<input name="accrual" type="date" value="'+(period?.accrual_start||'')+'" required></label>'+
  '<label>Data limite<input name="limit" type="date" value="'+(period?.deadline||'')+'" required></label>'+
  '<label>Início das férias<input name="start" type="date" value="'+(period?.vacation_start||'')+'"></label>'+
  '<label>Término das férias<input name="end" type="date" value="'+(period?.vacation_end||'')+'"></label>'+
  '<div class="wide"><button class="primary">Salvar programação</button></div></form>';
}
function shiftCalendarMonth(date,months){
 const start=new Date(date+'T00:00:00Z'), day=start.getUTCDate();
 start.setUTCDate(1);start.setUTCMonth(start.getUTCMonth()+months);
 const last=new Date(Date.UTC(start.getUTCFullYear(),start.getUTCMonth()+1,0)).getUTCDate();
 start.setUTCDate(Math.min(day,last));return start;
}
function showVacationPanel(periods,workers){
 const planner=canTeamPlan();
 const priorities={planned:'Programadas',overdue:'Prazo vencido',urgent:'Urgente · até 2 meses',warning:'Planejar · até 6 meses',normal:'No prazo'};
 teamPanel.innerHTML='<h2>Programação de férias</h2><p class="muted team-intro">'+(planner?
   'Confira os prazos cadastrados. Os avisos vão à Assistência do turno e à Coordenação a seis e a dois meses do prazo.':
   'Confira seu período e solicite a programação à Assistência do turno e à Coordenação.')+'</p>'+
  (planner&&workers.length?'<details class="team-card"><summary>Cadastrar período</summary>'+vacationForm(null,workers)+'</details>':'')+
  '<div class="team-stack">'+(periods.map(p=>'<details class="team-card"><summary><span class="team-summary">'+teamEscape(p.full_name)+
   ' · Turno '+teamEscape(p.shift)+' '+teamTag(priorities[p.priority],p.priority)+'</span></summary>'+
   '<p>Admissão <strong>'+teamDate(p.admission_date)+'</strong> · Início do aquisitivo <strong>'+teamDate(p.accrual_start)+'</strong></p>'+
   '<p>Data limite <strong>'+teamDate(p.deadline)+'</strong></p>'+
   (p.vacation_start?'<p>Férias de <strong>'+teamDate(p.vacation_start)+' a '+teamDate(p.vacation_end)+'</strong>.</p>':'')+
   (p.requested_at?'<p>Pedido em '+teamEscape(teamStamp(p.requested_at))+(p.request_date?' · Preferência '+teamDate(p.request_date):'')+
    (p.request_note?' · '+teamEscape(p.request_note):'')+'</p>':'')+
   (planner?vacationForm(p,workers):!p.requested_at&&!p.vacation_start?'<form class="team-form" data-vacation-request="'+p.id+
    '"><label>Data de preferência (opcional)<input type="date" name="preferred" min="'+todayTeam()+'" max="'+p.deadline+
    '"></label><label>Mensagem (opcional)<input name="note" maxlength="300"></label><div class="wide"><button class="primary">Pedir programação</button></div></form>':'')+'</details>').join('')||
   '<p class="muted">Nenhum período cadastrado neste perfil.</p>')+'</div>';
 teamPanel.querySelectorAll('[data-vacation-period]').forEach(form=>{
  const fields=form.elements;
  fields.admission.onchange=()=>{if(!fields.accrual.value&&fields.admission.value){fields.accrual.value=fields.admission.value;fields.accrual.onchange()}};
  if(fields.worker.tagName==='SELECT')fields.worker.onchange=()=>{
   const person=workers.find(row=>row.registration===fields.worker.value);
   if(person?.admission_date&&!fields.admission.value){fields.admission.value=person.admission_date;fields.admission.onchange()}
  };
  fields.accrual.onchange=()=>{
   if(fields.accrual.value){
    const suggested=shiftCalendarMonth(fields.accrual.value,24);suggested.setUTCDate(suggested.getUTCDate()-1);
    fields.limit.value=suggested.toISOString().slice(0,10);
   }
  };
  form.onsubmit=event=>{
   event.preventDefault();
   void teamSubmit(form,event.submitter,'panel_vacation_save',{period_id:form.dataset.vacationPeriod||null,
    target_registration:fields.worker.value,admission:fields.admission.value,accrual:fields.accrual.value,
    limit_day:fields.limit.value,start_day:fields.start.value||null,end_day:fields.end.value||null},
    fields.start.value?'Férias publicadas na escala.':'Período registrado.',true);
  };
 });
 teamPanel.querySelectorAll('[data-vacation-request]').forEach(form=>{form.onsubmit=event=>{
  event.preventDefault();
  void teamSubmit(form,event.submitter,'panel_vacation_request',{period_id:form.dataset.vacationRequest,
    preferred_date:form.elements.preferred.value||null,message:form.elements.note.value},'Pedido encaminhado à Gestão.');
 }});
}
function showTeamDirectory(areas,rosters){
 const roleSlots=[['coordinator','Coordenação'],['supervisor','Supervisão'],['A','Assistência · Turno A'],
  ['B','Assistência · Turno B'],['C','Assistência · Turno C']];
 teamPanel.innerHTML='<h2>Hierarquia de Envase e Refinaria</h2><p class="muted team-intro">'+
  'Coordenação, Supervisão e equipes por turno. Em cada setor, a Assistência do turno A também atende a equipe do Geral.</p>'+
  '<div class="team-stack roster-sectors">'+areas.map((area,index)=>{
   const {people=[],slots=[]}=rosters[index]||{};
   const occupied=new Set(slots.map(slot=>slot.registration).filter(Boolean));
   const supervisor=slots.find(slot=>slot.slot==='supervisor');
   const coordinator=slots.find(slot=>slot.slot==='coordinator');
   return '<article class="team-card roster-sector"><h3>'+sectors[area]+'</h3><div class="roster-grid">'+roleSlots.map(([slot,label])=>{
    const current=slots.find(item=>item.slot===slot);
    const isShift=slot.length===1;
    const candidates=people.filter(person=>(!occupied.has(person.registration)||person.registration===current?.registration)&&
     (isShift?person.sector===area&&person.shift===slot:slot==='coordinator'?person.manager||person.sector===area:person.sector===area));
    const team=isShift?people.filter(person=>person.sector===area&&(person.shift===slot||slot==='A'&&person.shift==='G')&&!occupied.has(person.registration)):[];
    const reportsTo=isShift?supervisor?.name:slot==='supervisor'?coordinator?.name:'';
    return '<section class="team-level roster-role"><h4>'+label+'</h4>'+
     '<p><strong>'+teamEscape(current?.name||'Sem responsável')+'</strong></p>'+
     (current?teamTag(current.active?'Acesso ativo':'Vínculo pendente',current.active?'approved':'pending'):'')+
     (current?.email?'<p class="muted">'+teamEscape(current.email)+'</p>':'')+
     (reportsTo?'<p class="muted">Responde a '+teamEscape(reportsTo)+'</p>':'')+
     (isShift?'<details><summary>'+team.length+(team.length===1?' colaborador':' colaboradores')+'</summary>'+
      (team.length?'<ul>'+team.map(person=>'<li>'+teamEscape(person.name)+(person.shift==='G'?' <span class="team-tag">Geral</span>':'')+'</li>').join('')+'</ul>':'<p>Nenhum colaborador neste turno.</p>')+'</details>':'')+
     (isManager()?'<details class="roster-settings"><summary>'+ (current?'Trocar responsável':'Definir responsável') +'</summary><form class="team-form" data-roster-area="'+area+'" data-roster-slot="'+slot+'"><label>Responsável<select name="person">'+
      teamOption('',current&&!current.registration?'Cadastro pendente':'Sem responsável')+
      candidates.map(person=>teamOption(person.registration,person.name,person.registration===current?.registration)).join('')+
      '</select></label><button class="primary" '+(!current?.registration?'disabled':'')+'>Salvar vínculo</button></form></details>':'')+
     '</section>';
   }).join('')+'</div></article>';
  }).join('')+'</div>';
 teamPanel.querySelectorAll('[data-roster-slot]').forEach(form=>{
  const submit=form.querySelector('button');
  const initial=form.elements.person.value;
  form.elements.person.onchange=()=>{submit.disabled=!form.elements.person.value&&!initial};
  form.onsubmit=event=>{
  event.preventDefault();
  void teamSubmit(form,event.submitter,'panel_roster_assign',{
   target_sector:form.dataset.rosterArea,target_slot:form.dataset.rosterSlot,employee_registration:form.elements.person.value||null
  },'Vínculo atualizado. Confira a situação da conta na hierarquia.');
 }});
}
for(const key of teamTabs)$(key+'-tab').onclick=()=>{if(teamVisible(key))changeScreen(key)};
void query(client.rpc('panel_team_context',{target_sector:currentSector()})).then(data=>{
 teamMember=data;redraw();
}).catch(()=>{});
