const fs = require('node:fs');
const path = require('node:path');

const source = fs.readFileSync(path.join(__dirname, 'painel.template.html'), 'utf8');
const defaults = {};
const config = path.join(__dirname, '.env.local');
if (fs.existsSync(config)) {
  for (const line of fs.readFileSync(config, 'utf8').split(/\r?\n/)) {
    const match = /^(SUPABASE_URL|SUPABASE_PUBLISHABLE_KEY)=(.+)$/.exec(line.trim());
    if (match) defaults[match[1]] = match[2].trim();
  }
}

const url = process.env.SUPABASE_URL || defaults.SUPABASE_URL;
const key = process.env.SUPABASE_PUBLISHABLE_KEY || defaults.SUPABASE_PUBLISHABLE_KEY;
if (!/^https:\/\/[a-z0-9]+\.supabase\.co$/.test(url || '') ||
    !/^sb_publishable_[A-Za-z0-9_-]+$/.test(key || '')) {
  throw new Error('Configure SUPABASE_URL e SUPABASE_PUBLISHABLE_KEY antes de gerar o painel.');
}

const html = source
  .replace('"__SUPABASE_URL__"', () => JSON.stringify(url))
  .replace('"__SUPABASE_PUBLISHABLE_KEY__"', () => JSON.stringify(key));
const out = path.join(__dirname, 'dist');
fs.mkdirSync(out, {recursive: true});
const webHtml = html.replace(
  /(<source type="video\/(mp4|webm)" src=")data:video\/\2;base64,([a-z0-9+/=]+)"/gi,
  (_, prefix, extension, base64) => {
    const name = 'abertura.' + extension;
    fs.writeFileSync(path.join(out, name), Buffer.from(base64, 'base64'));
    return prefix + name + '"';
  }
);
if (!webHtml.includes('src="abertura.mp4"') || !webHtml.includes('src="abertura.webm"')) {
  throw new Error('Arquivos de abertura ausentes no HTML.');
}
const preferredVideo = webHtml.replace(
  /(<source type="video\/mp4" src="abertura\.mp4">)\s*(<source type="video\/webm" src="abertura\.webm">)/,
  '$2$1'
);
fs.writeFileSync(path.join(out, 'index.html'), preferredVideo);
console.log('Painel gerado em dist/index.html');
