const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const html = fs.readFileSync(path.join(__dirname, '../painel.template.html'), 'utf8');
const functions = html.slice(html.indexOf('function samePayload('), html.indexOf('async function readPanelData('));
const context = vm.createContext({});
vm.runInContext(functions, context);
const data = JSON.parse(fs.readFileSync(path.join(__dirname, 'dados-ficticios.json'), 'utf8').replace(/^\uFEFF/, ''));
const copy = value => JSON.parse(JSON.stringify(value));
for (const [sector, rows] of Object.entries(data)) {
  const start = {DB:{prod:[],falhas:[],ordem:{}}};
  const imported = {DB:{...start.DB,prod:rows.map(item => item.payload)}};
  assert.deepEqual(copy(context.panelChanges(sector, start, imported)), {producao:rows});
  assert.deepEqual(copy(context.panelChanges(sector, imported, copy(imported))), {});
  const corrected = copy(imported);
  corrected.DB.prod[0].q += 1;
  assert.equal(copy(context.panelChanges(sector, imported, corrected)).producao[0].payload.q, corrected.DB.prod[0].q);
  assert.equal(context.samePayload({a:1,b:2}, {b:2,a:1}), true);
}
console.log('Envase e Refinaria: novos, idênticos e corrigidos passaram.');
