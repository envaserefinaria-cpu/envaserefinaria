-- Estrutura inicial. A concessão do primeiro gestor é feita pelo administrador do projeto.
create table public.panel_profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  role text not null check (role in ('operator', 'management')),
  sector text check (sector in ('envase', 'refinaria')),
  approved boolean not null default false,
  check (role <> 'operator' or sector is not null)
);

alter table public.panel_profiles enable row level security;
revoke all on public.panel_profiles from anon, authenticated;
grant select on public.panel_profiles to authenticated;
create policy panel_profile_self on public.panel_profiles
  for select to authenticated using (user_id = (select auth.uid()));

-- Um registro operacional atual por setor, tipo e identificador da origem.
-- Ordens usam a data e, na Refinaria, também a etapa como identificador.
create table public.panel_records (
  sector text not null check (sector in ('envase', 'refinaria')),
  kind text not null check (kind in ('producao', 'parada', 'ordem')),
  source_id text not null check (btrim(source_id) <> ''),
  payload jsonb not null check (jsonb_typeof(payload) = 'object'),
  updated_at timestamptz not null default now(),
  primary key (sector, kind, source_id)
);

alter table public.panel_records enable row level security;
revoke all on public.panel_records from anon, authenticated;
grant select, insert on public.panel_records to authenticated;
grant update (payload, updated_at) on public.panel_records to authenticated;

create policy panel_read_sector on public.panel_records
  for select to authenticated using (
    exists (
      select 1 from public.panel_profiles p
      where p.user_id = (select auth.uid()) and p.approved
        and (p.role = 'management' or p.sector = panel_records.sector)
    )
  );

create policy panel_insert_sector on public.panel_records
  for insert to authenticated with check (
    exists (
      select 1 from public.panel_profiles p
      where p.user_id = (select auth.uid()) and p.approved
        and (p.role = 'management' or (p.sector = panel_records.sector and panel_records.kind <> 'ordem'))
    )
  );

create policy panel_update_sector on public.panel_records
  for update to authenticated using (
    exists (
      select 1 from public.panel_profiles p
      where p.user_id = (select auth.uid()) and p.approved
        and (p.role = 'management' or (p.sector = panel_records.sector and panel_records.kind <> 'ordem'))
    )
  );

-- Processa o lote numa única transação. A chave primária resolve conflitos
-- concorrentes e a comparação integral em JSONB evita regravar linhas iguais.
create function public.panel_import(target_sector text, target_kind text, entries jsonb)
returns table (gravados bigint, identicos bigint)
language plpgsql
security invoker
set search_path = ''
as $$
declare
  entry jsonb;
  affected bigint;
begin
  if jsonb_typeof(entries) is distinct from 'array' then
    raise exception 'O lote deve ser uma lista de registros';
  end if;
  gravados := 0;
  identicos := 0;
  for entry in select value from jsonb_array_elements(entries)
  loop
    insert into public.panel_records as stored (sector, kind, source_id, payload)
    values (target_sector, target_kind, entry->>'source_id', entry->'payload')
    on conflict (sector, kind, source_id) do update
      set payload = excluded.payload, updated_at = now()
      where stored.payload is distinct from excluded.payload;
    get diagnostics affected = row_count;
    gravados := gravados + affected;
    identicos := identicos + (1 - affected);
  end loop;
  return next;
end;
$$;

revoke all on function public.panel_import(text, text, jsonb) from public, anon;
grant execute on function public.panel_import(text, text, jsonb) to authenticated;
