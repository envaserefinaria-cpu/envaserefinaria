begin;

create function public.panel_delete_collaborator(target_user uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
  lock table public.panel_profiles in share row exclusive mode;

  if not public.panel_schedule_is_manager() then
    raise exception 'Acesso de gestor necessário' using errcode = '42501';
  end if;
  if target_user is null or target_user = auth.uid() then
    raise exception 'Sua própria conta não pode ser excluída';
  end if;
  if exists (
    select 1 from public.panel_profiles p
    where p.user_id = target_user and p.role = 'management' and p.approved
  ) then
    raise exception 'Revogue primeiro o acesso do outro gestor';
  end if;

  delete from auth.users u
  where u.id = target_user
    and (
      lower(u.email) ~ '^[^@]+@coamo\.com\.br$'
      or exists (select 1 from public.panel_profiles p where p.user_id = u.id)
    );
  if not found then
    raise exception 'Colaborador não encontrado no painel';
  end if;
end;
$$;

revoke all on function public.panel_delete_collaborator(uuid) from public, anon, authenticated;
grant execute on function public.panel_delete_collaborator(uuid) to authenticated;

commit;
