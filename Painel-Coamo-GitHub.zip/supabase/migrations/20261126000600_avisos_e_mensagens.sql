begin;

create table public.panel_notices (
  id uuid primary key default gen_random_uuid(),
  recipient_id uuid not null references public.panel_profiles(user_id) on delete cascade,
  sender_id uuid references public.panel_profiles(user_id) on delete set null,
  kind text not null check (kind in ('schedule', 'message')),
  sector text check (sector in ('envase', 'refinaria')),
  subject text not null check (length(btrim(subject)) between 1 and 100),
  body text not null check (length(btrim(body)) between 1 and 2000),
  created_at timestamptz not null default now(),
  read_at timestamptz,
  check ((kind = 'schedule') = (sector is not null))
);

create index panel_notices_inbox on public.panel_notices (recipient_id, created_at desc, id);
create index panel_notices_unread on public.panel_notices (recipient_id) where read_at is null;
alter table public.panel_notices enable row level security;
revoke all on public.panel_notices from public, anon, authenticated;
grant select (id, kind, sector, subject, body, created_at, read_at) on public.panel_notices to authenticated;
grant update (read_at) on public.panel_notices to authenticated;

create policy panel_notices_recipient on public.panel_notices for select to authenticated
using (recipient_id = (select auth.uid()) and exists (
  select 1 from public.panel_profiles p where p.user_id = (select auth.uid()) and p.approved
    and (panel_notices.sector is null or p.role = 'management' or p.sector = panel_notices.sector)
));
create policy panel_notices_recipient_read on public.panel_notices for update to authenticated
using (recipient_id = (select auth.uid()) and exists (
  select 1 from public.panel_profiles p where p.user_id = (select auth.uid()) and p.approved
    and (panel_notices.sector is null or p.role = 'management' or p.sector = panel_notices.sector)
));

create function public.panel_my_display_name()
returns text language sql stable security definer set search_path = ''
as $$
  select coalesce(nullif(btrim(s.full_name), ''), nullif(btrim(u.raw_user_meta_data->>'name'), ''), u.email::text)
  from public.panel_profiles p
  join auth.users u on u.id = p.user_id
  left join public.panel_staff s on s.user_id = p.user_id
  where p.user_id = (select auth.uid()) and p.approved;
$$;

create function public.panel_send_message(target_user uuid, message_subject text, message_body text)
returns void language plpgsql security definer set search_path = ''
as $$
begin
  if not public.panel_schedule_is_manager() then
    raise exception 'Acesso de gestor necessário' using errcode = '42501';
  end if;
  if not exists (
    select 1 from public.panel_profiles p join auth.users u on u.id = p.user_id
    where p.user_id = target_user and p.approved and u.email_confirmed_at is not null
  ) then
    raise exception 'O destinatário precisa ter uma conta ativa' using errcode = '22023';
  end if;
  insert into public.panel_notices (recipient_id, sender_id, kind, subject, body)
  values (target_user, auth.uid(), 'message', btrim(message_subject), btrim(message_body));
end;
$$;

create function public.panel_notice_on_schedule_change()
returns trigger language plpgsql security definer set search_path = ''
as $$
declare
  affected_sector text;
  previous_payload jsonb;
  next_payload jsonb;
begin
  if tg_op = 'UPDATE' and old.payload is not distinct from new.payload then
    return null;
  end if;
  if tg_op <> 'INSERT' then
    affected_sector := old.sector;
    previous_payload := old.payload;
  end if;
  if tg_op <> 'DELETE' then
    affected_sector := new.sector;
    next_payload := new.payload;
  end if;

  insert into public.panel_notices (recipient_id, sender_id, kind, sector, subject, body)
  select p.user_id, auth.uid(), 'schedule', affected_sector, 'A escala foi atualizada',
    'Consulte a versão publicada em Escala e agenda.'
  from public.panel_profiles p
  left join public.panel_staff s on s.user_id = p.user_id and s.sector = affected_sector
  where p.approved and p.role = 'operator' and p.sector = affected_sector
    and (
      'all' in (previous_payload->>'shift', next_payload->>'shift')
      or s.shift in (previous_payload->>'shift', next_payload->>'shift')
      or s.registration in (previous_payload->>'employeeId', next_payload->>'employeeId')
    );
  return null;
end;
$$;

create trigger panel_notice_after_schedule_change
after insert or update or delete on public.panel_schedule_public
for each row execute function public.panel_notice_on_schedule_change();

revoke all on function public.panel_my_display_name(), public.panel_send_message(uuid, text, text),
  public.panel_notice_on_schedule_change() from public, anon, authenticated;
grant execute on function public.panel_my_display_name(), public.panel_send_message(uuid, text, text) to authenticated;

commit;
