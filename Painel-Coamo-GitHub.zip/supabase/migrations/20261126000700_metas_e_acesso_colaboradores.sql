begin;

alter table public.panel_notices drop constraint panel_notices_kind_check;
alter table public.panel_notices drop constraint panel_notices_check;
alter table public.panel_notices add check (kind in ('schedule', 'message', 'goal'));
alter table public.panel_notices add check ((kind <> 'message') = (sector is not null));
alter policy panel_notices_recipient on public.panel_notices using (
  recipient_id = (select auth.uid()) and exists (
    select 1 from public.panel_profiles p where p.user_id = (select auth.uid()) and p.approved
      and (panel_notices.kind <> 'schedule' or p.role = 'management' or p.sector = panel_notices.sector)
  )
);
alter policy panel_notices_recipient_read on public.panel_notices using (
  recipient_id = (select auth.uid()) and exists (
    select 1 from public.panel_profiles p where p.user_id = (select auth.uid()) and p.approved
      and (panel_notices.kind <> 'schedule' or p.role = 'management' or p.sector = panel_notices.sector)
  )
);

create table public.panel_reached_goals (
  sector text not null,
  month text not null,
  stage text not null,
  primary key (sector, month, stage)
);
alter table public.panel_reached_goals enable row level security;
revoke all on public.panel_reached_goals from public, anon, authenticated;

create function public.panel_check_monthly_goals(target_sector text, target_month text)
returns void language plpgsql security definer set search_path = ''
as $$
begin
  if target_month is null or target_month !~ '^[0-9]{4}-(0[1-9]|1[0-2])$'
    or not exists (
      select 1 from public.panel_profiles p where p.user_id = auth.uid() and p.approved
        and (p.role = 'management' or p.sector = target_sector)
    ) then
    return;
  end if;

  with stages(stage, label, product) as (
    select * from (values
      ('envase', 'Envase', ''),
      ('919', 'Refinaria · Degomagem', 'oleo de soja neutro seco'),
      ('1043', 'Refinaria · Branqueamento', 'oleo de soja branqueado - nb'),
      ('559', 'Refinaria · Desodorização', 'oleo de soja branq/desodorizado - nbd')
    ) as s(code, name, material) where (code = 'envase') = (target_sector = 'envase')
  ), days as (
    select s.stage, sum((r.payload->>'q')::numeric) as actual
    from public.panel_records r join stages s on (s.stage = 'envase' or (
      public.panel_staff_name_key(r.payload->>'u') = 'kg'
      and public.panel_staff_name_key(r.payload->>'p') = s.product
      and (r.payload->>'process' is null or r.payload->>'process' = s.stage)
    ))
    where r.sector = target_sector and r.kind = 'producao' and r.payload->>'n' = '203'
      and r.payload->>'d' ~ ('^' || target_month || '-[0-9]{2}$')
      and r.payload->>'t' in ('1','2','3') and jsonb_typeof(r.payload->'q') = 'number'
    group by s.stage, r.payload->>'d' having count(distinct r.payload->>'t') = 3
  ), plans as (
    select s.stage, sum((r.payload->>'quantity')::numeric) as target
    from public.panel_records r join stages s on r.source_id ~ (
      '^' || case when s.stage = 'envase' then '' else s.stage || '/' end || target_month || '-[0-9]{2}$')
    where r.sector = target_sector and r.kind = 'ordem' and jsonb_typeof(r.payload->'quantity') = 'number'
      and r.payload->'deleted' is distinct from 'true'::jsonb
    group by s.stage
  ), announced as (
    insert into public.panel_reached_goals (sector, month, stage)
    select target_sector, target_month, d.stage
    from days d join plans p using (stage)
    where p.target > 0 group by d.stage, p.target having sum(d.actual) >= p.target
    on conflict do nothing returning stage
  )
  insert into public.panel_notices (recipient_id, kind, sector, subject, body)
  select p.user_id, 'goal', target_sector, 'Meta mensal batida · ' || s.label,
    'A produção realizada atingiu a ordem cadastrada de ' ||
    right(target_month, 2) || '/' || left(target_month, 4) || '.'
  from announced a join stages s using (stage)
  cross join public.panel_profiles p where p.approved;
end;
$$;
revoke all on function public.panel_check_monthly_goals(text,text) from public, anon, authenticated;
grant execute on function public.panel_check_monthly_goals(text,text) to authenticated;

create or replace function public.panel_sync(target_sector text, batches jsonb, history_entry jsonb default null)
returns table (gravados bigint, identicos bigint)
language plpgsql security invoker set search_path = ''
as $$
declare batch record; result record; goal_month text;
begin
  if jsonb_typeof(batches) is distinct from 'object' then
    raise exception 'Formato de sincronização inválido';
  end if;
  gravados := 0;
  identicos := 0;
  for batch in select key,value from jsonb_each(batches) order by key loop
    select * into result from public.panel_import(target_sector,batch.key,batch.value);
    gravados := gravados + result.gravados;
    identicos := identicos + result.identicos;
  end loop;
  if gravados > 0 and history_entry is not null then
    perform public.panel_import(target_sector,'historico',jsonb_build_array(history_entry));
  end if;
  if gravados > 0 then
    for goal_month in
      select distinct substring(item->'payload'->>'d' from '^[0-9]{4}-[0-9]{2}')
      from jsonb_array_elements(coalesce(batches->'producao','[]'::jsonb)) item
      union
      select distinct substring(item->>'source_id' from '([0-9]{4}-[0-9]{2})-[0-9]{2}$')
      from jsonb_array_elements(coalesce(batches->'ordem','[]'::jsonb)) item
    loop
      perform public.panel_check_monthly_goals(target_sector,goal_month);
    end loop;
  end if;
  return next;
end;
$$;

-- Used only by the server function after verifying the caller's Auth token.
create function public.panel_staff_login_target(manager_id uuid, employee_registration text, corporate_email text,
  attach_user uuid default null)
returns jsonb language plpgsql security definer set search_path = ''
as $$
declare
  employee public.panel_staff%rowtype;
  account_id uuid;
  account_name text;
begin
  if not exists (select 1 from public.panel_profiles p where p.user_id = manager_id and p.approved and p.role = 'management') then
    raise exception 'Gestão aprovada necessária' using errcode = '42501';
  end if;
  if corporate_email is null or corporate_email !~ '^[^[:space:]@]+@coamo\.com\.br$' then
    raise exception 'E-mail corporativo inválido' using errcode = '22023';
  end if;
  select * into employee from public.panel_staff s where s.registration = employee_registration for update;
  if not found or employee.sector is null then
    raise exception 'Colaborador sem setor' using errcode = '22023';
  end if;
  select u.id, u.raw_user_meta_data->>'name' into account_id, account_name
  from auth.users u where lower(u.email) = corporate_email and coalesce(u.is_sso_user,false) = false;
  if (employee.user_id is not null and employee.user_id is distinct from account_id) or
    (account_id is not null and
      (public.panel_staff_name_key(account_name) is distinct from public.panel_staff_name_key(employee.full_name)
        or exists (select 1 from public.panel_staff s where s.user_id = account_id and s.registration <> employee.registration)
        or exists (select 1 from public.panel_profiles p where p.user_id = account_id
          and (p.role <> 'operator' or p.sector is distinct from employee.sector or not p.approved))
      )) then
    raise exception 'Conflito com conta existente' using errcode = '23505';
  end if;
  if attach_user is not null then
    if account_id is distinct from attach_user then
      raise exception 'Convite não corresponde ao e-mail' using errcode = '22023';
    end if;
    insert into public.panel_profiles(user_id, role, sector, approved)
    values (account_id, 'operator', employee.sector, true)
    on conflict (user_id) do nothing;
    if not exists (select 1 from public.panel_profiles p where p.user_id = account_id and p.role = 'operator'
      and p.sector = employee.sector and p.approved) then
      raise exception 'Perfil incompatível' using errcode = '23505';
    end if;
    update public.panel_staff set user_id = account_id where registration = employee.registration;
  end if;
  return jsonb_build_object('id',account_id,'name',employee.full_name,'sector',employee.sector);
end;
$$;
revoke all on function public.panel_staff_login_target(uuid,text,text,uuid) from public, anon, authenticated;
grant execute on function public.panel_staff_login_target(uuid,text,text,uuid) to service_role;

commit;
