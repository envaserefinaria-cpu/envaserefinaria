begin;
alter table public.panel_staff drop constraint if exists panel_staff_shift_check;
alter table public.panel_staff add constraint panel_staff_shift_check check (shift in ('A','B','C','G'));
commit;
