begin;
alter table public.panel_profiles
  add column allow_external_email boolean not null default false;
create unique index panel_single_external_account
  on public.panel_profiles (allow_external_email)
  where allow_external_email;
commit;
