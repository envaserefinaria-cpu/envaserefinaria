begin;
create function public.panel_manage_list()
returns table(user_id uuid,email text,name text,role text,sector text,approved boolean,confirmed boolean)
language plpgsql security definer set search_path = ''
as $$
begin
 if not exists(select 1 from public.panel_profiles p where p.user_id=auth.uid() and p.role='management' and p.approved) then
  raise exception 'Acesso de gestor necessário' using errcode='42501';
 end if;
 return query
 select u.id,u.email::text,coalesce(u.raw_user_meta_data->>'name',''),coalesce(p.role,u.raw_user_meta_data->>'requested_role','operator'),
        coalesce(p.sector,u.raw_user_meta_data->>'requested_sector'),coalesce(p.approved,false),u.email_confirmed_at is not null
 from auth.users u left join public.panel_profiles p on p.user_id=u.id
 where lower(u.email) ~ '^[^@]+@coamo\.com\.br$' or coalesce(p.allow_external_email,false)
 order by u.email;
end;
$$;
create function public.panel_manage_access(target_user uuid,operation text,operator_sector text default null)
returns void language plpgsql security definer set search_path = ''
as $$
begin
 lock table public.panel_profiles in share row exclusive mode;
 if not exists(select 1 from public.panel_profiles p where p.user_id=auth.uid() and p.role='management' and p.approved) then
  raise exception 'Acesso de gestor necessário' using errcode='42501';
 end if;
 if target_user is null or target_user=auth.uid() then
  raise exception 'Edite apenas o acesso de outra conta';
 end if;
 if operation='revoke' then
  update public.panel_profiles set approved=false where user_id=target_user;
  return;
 end if;
 if not exists(
  select 1 from auth.users u left join public.panel_profiles p on p.user_id=u.id
  where u.id=target_user and u.email_confirmed_at is not null
    and (lower(u.email) ~ '^[^@]+@coamo\.com\.br$' or coalesce(p.allow_external_email,false))
 ) then
  raise exception 'Conta sem confirmação de e-mail ou fora do domínio autorizado';
 end if;
 if operation='operator' and operator_sector in ('envase','refinaria') then
  insert into public.panel_profiles(user_id,role,sector,approved) values(target_user,'operator',operator_sector,true)
  on conflict(user_id) do update set role=excluded.role,sector=excluded.sector,approved=true;
 elsif operation='management' then
  insert into public.panel_profiles(user_id,role,sector,approved) values(target_user,'management',null,true)
  on conflict(user_id) do update set role=excluded.role,sector=null,approved=true;
 else
  raise exception 'Ação ou setor inválido';
 end if;
end;
$$;
revoke all on function public.panel_manage_list() from public,anon,authenticated;
revoke all on function public.panel_manage_access(uuid,text,text) from public,anon,authenticated;
grant execute on function public.panel_manage_list() to authenticated;
grant execute on function public.panel_manage_access(uuid,text,text) to authenticated;
commit;
