begin;
create function public.panel_staff_auto_link(target_sector text)
returns integer
language plpgsql security definer set search_path = ''
as $$
declare linked integer;
begin
  if not public.panel_schedule_is_manager() then
    raise exception 'Acesso de gestor necessário' using errcode = '42501';
  end if;
  if target_sector is null or target_sector not in ('envase','refinaria') then
    raise exception 'Setor inválido' using errcode = '22023';
  end if;
  lock table public.panel_staff in share row exclusive mode;
  with staff_names as (
    select public.panel_staff_name_key(full_name) as name_key, min(registration) as registration
    from public.panel_staff
    where sector = target_sector
    group by 1 having count(*) = 1
  ), account_names as (
    select public.panel_staff_name_key(u.raw_user_meta_data->>'name') as name_key, (array_agg(u.id))[1] as user_id
    from auth.users u join public.panel_profiles p on p.user_id = u.id
    where p.sector = target_sector and p.role = 'operator' and p.approved and u.email_confirmed_at is not null
    group by 1 having count(*) = 1
  )
  update public.panel_staff s set user_id = a.user_id
  from staff_names n join account_names a using (name_key)
  where s.registration = n.registration and s.user_id is null
    and not exists (select 1 from public.panel_staff other where other.user_id = a.user_id);
  get diagnostics linked = row_count;
  return linked;
end;
$$;
revoke all on function public.panel_staff_auto_link(text) from public, anon, authenticated;
grant execute on function public.panel_staff_auto_link(text) to authenticated;
commit;
