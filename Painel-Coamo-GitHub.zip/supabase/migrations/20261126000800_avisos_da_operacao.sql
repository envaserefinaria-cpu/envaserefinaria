begin;

alter table public.panel_notices drop constraint panel_notices_kind_check;
alter table public.panel_notices add check (kind in ('schedule', 'message', 'goal', 'operation'));
alter policy panel_notices_recipient on public.panel_notices using (
  recipient_id = (select auth.uid()) and exists (
    select 1 from public.panel_profiles p where p.user_id = (select auth.uid()) and p.approved
      and (panel_notices.kind not in ('schedule','operation') or p.role = 'management' or p.sector = panel_notices.sector)
  )
);
alter policy panel_notices_recipient_read on public.panel_notices using (
  recipient_id = (select auth.uid()) and exists (
    select 1 from public.panel_profiles p where p.user_id = (select auth.uid()) and p.approved
      and (panel_notices.kind not in ('schedule','operation') or p.role = 'management' or p.sector = panel_notices.sector)
  )
);

create function public.panel_operation_recipients(target_sector text)
returns table (user_id uuid, name text, shift text)
language sql stable security definer set search_path = ''
as $$
  select p.user_id, coalesce(nullif(btrim(s.full_name),''), nullif(btrim(u.raw_user_meta_data->>'name'),''), u.email::text), s.shift
  from public.panel_profiles p
  join auth.users u on u.id = p.user_id and u.email_confirmed_at is not null
  left join public.panel_staff s on s.user_id = p.user_id and s.sector = p.sector
  where public.panel_schedule_is_manager() and p.approved and p.role = 'operator'
    and p.sector = target_sector
  order by 2, 1;
$$;

create function public.panel_send_operation_notice(target_sector text, audience text, target_shift text,
  target_users uuid[], message_subject text, message_body text)
returns integer language plpgsql security definer set search_path = ''
as $$
declare
  sent integer;
begin
  if not public.panel_schedule_is_manager() then
    raise exception 'Acesso de gestor necessário' using errcode = '42501';
  end if;
  if target_sector is null or target_sector not in ('envase','refinaria')
    or audience is null or audience not in ('people','shift','all')
    or (audience = 'shift' and (target_shift is null or target_shift not in ('A','B','C','G')))
    or (audience = 'people' and coalesce(cardinality(target_users),0) = 0) then
    raise exception 'Destinatários inválidos' using errcode = '22023';
  end if;

  insert into public.panel_notices (recipient_id, sender_id, kind, sector, subject, body)
  select r.user_id, auth.uid(), 'operation', target_sector, btrim(message_subject), btrim(message_body)
  from public.panel_operation_recipients(target_sector) r
  where audience = 'all' or (audience = 'shift' and r.shift = target_shift)
    or (audience = 'people' and r.user_id = any(target_users));
  get diagnostics sent = row_count;

  if sent = 0 or (audience = 'people' and sent <> (select count(distinct id) from unnest(target_users) as ids(id))) then
    raise exception 'Selecione apenas operadores ativos deste setor' using errcode = '22023';
  end if;
  return sent;
end;
$$;

revoke all on function public.panel_operation_recipients(text),
  public.panel_send_operation_notice(text,text,text,uuid[],text,text) from public, anon, authenticated;
grant execute on function public.panel_operation_recipients(text),
  public.panel_send_operation_notice(text,text,text,uuid[],text,text) to authenticated;

commit;
