begin;

-- Administrative mapping. The Auth password stays in Supabase Auth.
create table public.panel_staff (
  registration text primary key check (registration ~ '^[0-9]{1,20}$'),
  user_id uuid unique references public.panel_profiles(user_id) on delete set null,
  full_name text not null check (length(btrim(full_name)) between 1 and 100),
  position text not null check (length(btrim(position)) between 1 and 35),
  sector text check (sector in ('envase', 'refinaria')),
  shift text check (shift in ('A', 'B', 'C')),
  check ((sector is null) = (shift is null))
);

-- Drafts and public snapshots are separate so sector access never exposes edits in progress.
create table public.panel_schedule_drafts (
  id uuid primary key default gen_random_uuid(),
  sector text not null check (sector in ('envase', 'refinaria')),
  payload jsonb not null check (jsonb_typeof(payload) = 'object'),
  updated_at timestamptz not null default now(),
  unique (id, sector)
);

create table public.panel_schedule_public (
  id uuid primary key,
  sector text not null,
  payload jsonb not null check (jsonb_typeof(payload) = 'object'),
  published_at timestamptz not null default now(),
  published_by uuid references auth.users(id) on delete set null,
  foreign key (id, sector) references public.panel_schedule_drafts(id, sector) on delete restrict
);

alter table public.panel_staff enable row level security;
alter table public.panel_schedule_drafts enable row level security;
alter table public.panel_schedule_public enable row level security;

revoke all on public.panel_staff, public.panel_schedule_drafts, public.panel_schedule_public from anon, authenticated;
grant select, insert on public.panel_staff to authenticated;
grant update (full_name, position, sector, shift) on public.panel_staff to authenticated;
grant select, insert, delete on public.panel_schedule_drafts to authenticated;
grant update (payload, updated_at) on public.panel_schedule_drafts to authenticated;
grant select on public.panel_schedule_public to authenticated;
grant select, update on public.panel_staff to service_role;

create function public.panel_schedule_is_manager()
returns boolean language sql stable set search_path = ''
as $$
  select exists (
    select 1 from public.panel_profiles p
    where p.user_id = (select auth.uid()) and p.role = 'management' and p.approved
  );
$$;

revoke all on function public.panel_schedule_is_manager() from public, anon;
grant execute on function public.panel_schedule_is_manager() to authenticated;

create policy panel_staff_management on public.panel_staff
  for all to authenticated using ((select public.panel_schedule_is_manager()))
  with check ((select public.panel_schedule_is_manager()));

create policy panel_schedule_drafts_management on public.panel_schedule_drafts
  for all to authenticated using ((select public.panel_schedule_is_manager()))
  with check ((select public.panel_schedule_is_manager()));

create policy panel_schedule_public_access on public.panel_schedule_public
  for select to authenticated using (
    exists (
      select 1 from public.panel_profiles p
      where p.user_id = (select auth.uid()) and p.approved
        and (p.role = 'management' or (p.role = 'operator' and p.sector = panel_schedule_public.sector))
    )
  );

create function public.panel_publish_schedule(entry_id uuid, visible boolean)
returns void language plpgsql security definer set search_path = ''
as $$
declare
  draft public.panel_schedule_drafts%rowtype;
begin
  if not public.panel_schedule_is_manager() then
    raise exception 'Somente gestão aprovada pode publicar escalas' using errcode = '42501';
  end if;
  select * into strict draft from public.panel_schedule_drafts d where d.id = entry_id for update;
  if visible is false then
    delete from public.panel_schedule_public where id = entry_id;
    return;
  elsif visible is not true then
    raise exception 'Informe se o lançamento deve ficar visível' using errcode = '22023';
  end if;
  insert into public.panel_schedule_public(id, sector, payload, published_by)
  values (draft.id, draft.sector,
    jsonb_strip_nulls(jsonb_build_object(
      'type', draft.payload->'type', 'title', draft.payload->'title',
      'employeeId', draft.payload->'employeeId', 'position', draft.payload->'position',
      'shift', draft.payload->'shift', 'start', draft.payload->'start',
      'end', draft.payload->'end', 'time', draft.payload->'time',
      'details', draft.payload->'details', 'cycle', draft.payload->'cycle',
      'fixedDay', draft.payload->'fixedDay', 'extraDay', draft.payload->'extraDay',
      'code', draft.payload->'code'
    )), auth.uid())
  on conflict (id) do update set
    payload = excluded.payload,
    published_by = excluded.published_by,
    published_at = now();
end;
$$;

revoke all on function public.panel_publish_schedule(uuid, boolean) from public, anon;
grant execute on function public.panel_publish_schedule(uuid, boolean) to authenticated;

commit;
