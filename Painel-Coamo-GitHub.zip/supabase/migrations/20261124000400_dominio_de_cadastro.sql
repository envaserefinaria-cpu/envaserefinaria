begin;
create function public.panel_restrict_signup(event jsonb)
returns jsonb language sql stable set search_path = ''
as $$
 select case
  when lower(coalesce(event->'user'->>'email','')) ~ '^[^[:space:]@]+@coamo\.com\.br$'
   then '{}'::jsonb
  else jsonb_build_object('error',jsonb_build_object('http_code',403,'message','Use um e-mail terminado em @coamo.com.br.'))
 end;
$$;
revoke all on function public.panel_restrict_signup(jsonb) from public,anon,authenticated;
grant usage on schema public to supabase_auth_admin;
grant execute on function public.panel_restrict_signup(jsonb) to supabase_auth_admin;
commit;
