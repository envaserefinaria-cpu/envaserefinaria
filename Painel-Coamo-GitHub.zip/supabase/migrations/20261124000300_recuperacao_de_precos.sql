begin;
create function public.panel_recover_prices(target_sector text, monthly_prices jsonb)
returns integer language plpgsql security invoker set search_path = ''
as $$
declare month_entry record; current_rates jsonb; imported_rates jsonb; merged_rates jsonb; changed integer:=0;
begin
 if target_sector not in ('envase','refinaria') or target_sector is null or
    jsonb_typeof(monthly_prices) is distinct from 'object' then
  raise exception 'Formato inválido para recuperação de preços';
 end if;
 if not exists(select 1 from public.panel_profiles where user_id=(select auth.uid()) and role='management' and approved) then
  raise exception 'Acesso de gestor necessário' using errcode='42501';
 end if;
 for month_entry in select key,value from jsonb_each(monthly_prices) order by key loop
  if month_entry.key !~ '^[0-9]{4}-(0[1-9]|1[0-2])$' or jsonb_typeof(month_entry.value) is distinct from 'object' then
   raise exception 'Mês ou preços inválidos';
  end if;
  select coalesce(jsonb_object_agg(key,value),'{}'::jsonb) into imported_rates
  from jsonb_each(month_entry.value) where case when jsonb_typeof(value)='number' then (value #>> '{}')::numeric>=0 else false end;
  if imported_rates='{}'::jsonb then continue; end if;
  insert into public.panel_records(sector,kind,source_id,payload)
  values(target_sector,'configuracao','custos/'||month_entry.key,'{}'::jsonb)
  on conflict (sector,kind,source_id) do nothing;
  select coalesce(payload->'lossRates','{}'::jsonb) into current_rates from public.panel_records
  where sector=target_sector and kind='configuracao' and source_id='custos/'||month_entry.key for update;
  if jsonb_typeof(current_rates) is distinct from 'object' then current_rates:='{}'::jsonb; end if;
  changed:=changed+(select count(*)::integer from jsonb_object_keys(imported_rates) as k(name) where current_rates->k.name is null or current_rates->k.name='null'::jsonb);
  merged_rates:=current_rates || imported_rates || jsonb_strip_nulls(current_rates);
  if merged_rates is distinct from current_rates then
   update public.panel_records set payload=jsonb_set(payload,'{lossRates}',merged_rates),updated_at=now()
   where sector=target_sector and kind='configuracao' and source_id='custos/'||month_entry.key;
  end if;
 end loop;
 return changed;
end;
$$;
revoke all on function public.panel_recover_prices(text,jsonb) from public,anon,authenticated;
grant execute on function public.panel_recover_prices(text,jsonb) to authenticated;
commit;
