begin;
create function public.panel_staff_name_key(value text)
returns text language sql immutable strict set search_path = ''
as $$
  select translate(lower(regexp_replace(btrim(value), '[[:space:]]+', ' ', 'g')),
    'áàâãäéèêëíìîïóòôõöúùûüç', 'aaaaaeeeeiiiiooooouuuuc');
$$;

create function public.panel_staff_contacts(target_sector text)
returns table(registration text, email text, phone text)
language sql stable security definer set search_path = ''
as $$
  select s.registration, u.email::text,
    coalesce(nullif(u.raw_user_meta_data->>'requested_phone',''),nullif(u.phone,''))
  from public.panel_staff s
  join auth.users u on u.id = s.user_id
  where public.panel_schedule_is_manager() and s.sector = target_sector;
$$;

create function public.panel_staff_link_candidates(target_registration text)
returns table(user_id uuid, email text, phone text)
language sql stable security definer set search_path = ''
as $$
  select u.id, u.email::text,
    coalesce(nullif(u.raw_user_meta_data->>'requested_phone',''),nullif(u.phone,''))
  from public.panel_staff s
  join public.panel_profiles p on p.sector = s.sector and p.role = 'operator' and p.approved
  join auth.users u on u.id = p.user_id
  where public.panel_schedule_is_manager() and s.registration = target_registration
    and s.user_id is null and u.email_confirmed_at is not null
    and public.panel_staff_name_key(s.full_name) = public.panel_staff_name_key(u.raw_user_meta_data->>'name')
    and not exists (select 1 from public.panel_staff other where other.user_id = p.user_id)
  order by u.email;
$$;

create function public.panel_staff_link_account(target_registration text, target_user uuid)
returns void language plpgsql security definer set search_path = ''
as $$
begin
  if not public.panel_schedule_is_manager() then
    raise exception 'Acesso de gestor necessário' using errcode = '42501';
  end if;
  update public.panel_staff s
  set user_id = target_user
  where s.registration = target_registration and s.user_id is null
    and exists (select 1 from public.panel_staff_link_candidates(target_registration) c where c.user_id = target_user);
  if not found then raise exception 'Conta indisponível para vínculo'; end if;
end;
$$;

revoke all on function public.panel_staff_name_key(text), public.panel_staff_contacts(text),
  public.panel_staff_link_candidates(text), public.panel_staff_link_account(text,uuid) from public, anon, authenticated;
grant execute on function public.panel_staff_contacts(text), public.panel_staff_link_candidates(text),
  public.panel_staff_link_account(text,uuid) to authenticated;
commit;
