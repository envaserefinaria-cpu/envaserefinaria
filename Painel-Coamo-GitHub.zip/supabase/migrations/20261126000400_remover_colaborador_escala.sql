begin;
create function public.panel_remove_staff_from_sector(target_registration text, target_sector text)
returns void
language plpgsql security definer set search_path = ''
as $$
declare
  employee public.panel_staff%rowtype;
begin
  if not public.panel_schedule_is_manager() then
    raise exception 'Acesso de gestor necessário' using errcode = '42501';
  end if;
  select * into strict employee from public.panel_staff
  where registration = target_registration and sector = target_sector for update;
  if employee.user_id is null then
    delete from public.panel_staff where registration = target_registration;
  else
    update public.panel_staff set sector = null, shift = null where registration = target_registration;
  end if;
end;
$$;
revoke all on function public.panel_remove_staff_from_sector(text, text) from public, anon, authenticated;
grant execute on function public.panel_remove_staff_from_sector(text, text) to authenticated;
commit;
