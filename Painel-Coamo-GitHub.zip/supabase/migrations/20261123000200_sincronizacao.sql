begin;

alter table public.panel_records drop constraint panel_records_kind_check;
alter table public.panel_records add constraint panel_records_kind_check
 check (kind in ('producao','parada','ordem','energia','configuracao','historico'));

-- Existing sector policies still apply. Configuration writes require a manager.
create policy panel_config_insert on public.panel_records
 as restrictive for insert to authenticated with check (
 kind <> 'configuracao' or exists (
  select 1 from public.panel_profiles
  where user_id = (select auth.uid()) and approved and role = 'management'
 )
);
create policy panel_config_update on public.panel_records
 as restrictive for update to authenticated using (
 kind <> 'configuracao' or exists (
  select 1 from public.panel_profiles
  where user_id = (select auth.uid()) and approved and role = 'management'
 )
);

-- All parts of an import share a transaction. The history entry is stored
-- only after a production, failure, or order record actually changed.
create function public.panel_sync(target_sector text, batches jsonb, history_entry jsonb default null)
returns table (gravados bigint, identicos bigint)
language plpgsql security invoker set search_path = ''
as $$
declare batch record; result record;
begin
 if jsonb_typeof(batches) is distinct from 'object' then
  raise exception 'Formato de sincronização inválido';
 end if;
 gravados := 0;
 identicos := 0;
 for batch in select key,value from jsonb_each(batches) order by key loop
  select * into result from public.panel_import(target_sector,batch.key,batch.value);
  gravados := gravados + result.gravados;
  identicos := identicos + result.identicos;
 end loop;
 if gravados > 0 and history_entry is not null then
  perform public.panel_import(target_sector,'historico',jsonb_build_array(history_entry));
 end if;
 return next;
end;
$$;

revoke all on function public.panel_sync(text,jsonb,jsonb) from public,anon;
grant execute on function public.panel_sync(text,jsonb,jsonb) to authenticated;

commit;
