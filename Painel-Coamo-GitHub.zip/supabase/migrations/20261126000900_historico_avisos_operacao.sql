begin;

create table public.panel_operation_dispatches (
  id uuid primary key default gen_random_uuid(),
  sector text not null check (sector in ('envase','refinaria')),
  audience text not null check (audience in ('people','shift','all','legacy')),
  target_shift text check (target_shift in ('A','B','C','G')),
  subject text not null check (length(btrim(subject)) between 1 and 100),
  body text not null check (length(btrim(body)) between 1 and 2000),
  created_at timestamptz not null default now(),
  check ((audience = 'shift') = (target_shift is not null))
);
alter table public.panel_operation_dispatches enable row level security;
revoke all on public.panel_operation_dispatches from public, anon, authenticated;

alter table public.panel_notices
  add column operation_dispatch_id uuid references public.panel_operation_dispatches(id),
  add column operation_recipient_name text,
  add column operation_recipient_shift text;

-- Earlier sends used the same timestamp, sender and content for every recipient in a batch.
with legacy as (
  select sector, sender_id, subject, body, created_at, min(id::text)::uuid as dispatch_id
  from public.panel_notices where kind = 'operation'
  group by sector, sender_id, subject, body, created_at
), inserted as (
  insert into public.panel_operation_dispatches (id, sector, audience, subject, body, created_at)
  select dispatch_id, sector, 'legacy', subject, body, created_at from legacy
  returning id
), recipients as (
  select n.id, i.id as dispatch_id,
    coalesce(nullif(btrim(s.full_name),''), nullif(btrim(u.raw_user_meta_data->>'name'),''), u.email::text) as name,
    s.shift
  from public.panel_notices n
  join legacy l on n.sector = l.sector and n.sender_id is not distinct from l.sender_id
    and n.subject = l.subject and n.body = l.body and n.created_at = l.created_at
  join inserted i on i.id = l.dispatch_id
  join auth.users u on u.id = n.recipient_id
  left join public.panel_staff s on s.user_id = n.recipient_id and s.sector = n.sector
  where n.kind = 'operation'
)
update public.panel_notices n
set operation_dispatch_id = r.dispatch_id, operation_recipient_name = r.name, operation_recipient_shift = r.shift
from recipients r where n.id = r.id;

create index panel_operation_dispatches_sector_date on public.panel_operation_dispatches(sector, created_at desc, id desc);
create index panel_notices_operation_dispatch on public.panel_notices(operation_dispatch_id) where operation_dispatch_id is not null;

create or replace function public.panel_send_operation_notice(target_sector text, audience text, target_shift text,
  target_users uuid[], message_subject text, message_body text)
returns integer language plpgsql security definer set search_path = ''
as $$
declare
  sent integer;
  dispatch_id uuid;
begin
  if not public.panel_schedule_is_manager() then
    raise exception 'Acesso de gestor necessário' using errcode = '42501';
  end if;
  if target_sector is null or target_sector not in ('envase','refinaria')
    or audience is null or audience not in ('people','shift','all')
    or (audience = 'shift' and (target_shift is null or target_shift not in ('A','B','C','G')))
    or (audience = 'people' and coalesce(cardinality(target_users),0) = 0) then
    raise exception 'Destinatários inválidos' using errcode = '22023';
  end if;

  insert into public.panel_operation_dispatches (sector, audience, target_shift, subject, body)
  values (target_sector, audience, case when audience = 'shift' then target_shift end, btrim(message_subject), btrim(message_body))
  returning id into dispatch_id;

  insert into public.panel_notices (recipient_id, sender_id, kind, sector, subject, body,
    operation_dispatch_id, operation_recipient_name, operation_recipient_shift)
  select r.user_id, auth.uid(), 'operation', target_sector, btrim(message_subject), btrim(message_body),
    dispatch_id, r.name, r.shift
  from public.panel_operation_recipients(target_sector) r
  where audience = 'all' or (audience = 'shift' and r.shift = target_shift)
    or (audience = 'people' and r.user_id = any(target_users));
  get diagnostics sent = row_count;

  if sent = 0 or (audience = 'people' and sent <> (select count(distinct id) from unnest(target_users) as ids(id))) then
    raise exception 'Selecione apenas operadores ativos deste setor' using errcode = '22023';
  end if;
  return sent;
end;
$$;

create function public.panel_operation_history(target_sector text, before_created_at timestamptz default null, before_id uuid default null)
returns table (id uuid, subject text, body text, audience text, target_shift text, created_at timestamptz, recipients jsonb)
language plpgsql stable security definer set search_path = ''
as $$
begin
  if not public.panel_schedule_is_manager() then
    raise exception 'Acesso de gestor necessário' using errcode = '42501';
  end if;
  return query
  with page as (
    select d.* from public.panel_operation_dispatches d where d.sector = target_sector
      and (before_created_at is null or (d.created_at, d.id) < (before_created_at, before_id))
    order by d.created_at desc, d.id desc limit 11
  )
  select p.id, p.subject, p.body, p.audience, p.target_shift, p.created_at,
    coalesce(jsonb_agg(jsonb_build_object('name', coalesce(n.operation_recipient_name,'Colaborador'),
      'shift', n.operation_recipient_shift, 'read_at', n.read_at) order by n.operation_recipient_name, n.id)
      filter (where n.id is not null), '[]'::jsonb)
  from page p left join public.panel_notices n on n.operation_dispatch_id = p.id
  group by p.id, p.subject, p.body, p.audience, p.target_shift, p.created_at
  order by p.created_at desc, p.id desc;
end;
$$;
revoke all on function public.panel_operation_history(text,timestamptz,uuid) from public, anon, authenticated;
grant execute on function public.panel_operation_history(text,timestamptz,uuid) to authenticated;

commit;
