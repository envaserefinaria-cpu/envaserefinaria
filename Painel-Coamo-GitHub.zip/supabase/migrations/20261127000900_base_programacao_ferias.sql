begin;

create table public.panel_vacation_baseline (
 registration text primary key references public.panel_staff(registration) on delete cascade,
 recorded_start date,
 source_status text not null check (source_status in ('booked','proposed','cycle_pending')),
 check ((recorded_start is null) = (source_status = 'cycle_pending'))
);

alter table public.panel_vacation_baseline enable row level security;
revoke all on public.panel_vacation_baseline from public, anon, authenticated;

create function public.panel_vacation_baseline_list(target_sector text)
returns table(registration text,recorded_start date,source_status text)
language sql stable security definer set search_path=''
as $$
 select b.registration,b.recorded_start,b.source_status
 from public.panel_vacation_baseline b join public.panel_staff s using(registration)
 where s.sector=target_sector and public.panel_team_can_plan(s.sector,s.shift)
 order by b.registration;
$$;

revoke all on function public.panel_vacation_baseline_list(text) from public,anon,authenticated;
grant execute on function public.panel_vacation_baseline_list(text) to authenticated;

commit;
